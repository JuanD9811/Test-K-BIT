import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from configSubtestMatrices import obtener_preguntas_matrices, obtener_ruta_imagen
from PIL import Image, ImageTk
import json
import os
import guardarPDF
from datetime import datetime

RESULTADOS_JSON = "resultados.json"

class InterfazSubtestMatrices:
    def __init__(self, root, edad):
        self.root = root
        self.root.title("Test K-BIT - Subtest Matrices")
        self.root.geometry("1000x700")
        self.root.state('zoomed')
        self.root.configure(bg="#ddeeff")
        self.edad = edad
        self.preguntas = obtener_preguntas_matrices(edad)
        self.indice_pregunta = 0
        self.respuestas_usuario = []
        
        self.crear_interfaz()
        self.mostrar_pregunta()

    def crear_interfaz(self):
        self.frame = ttk.Frame(self.root, padding=20, relief="ridge", borderwidth=2, style="TFrame")
        self.frame.place(relx=0.5, rely=0.5, anchor=tk.CENTER)
        
        self.lbl_edad = ttk.Label(self.frame, text=f"Edad: {self.edad} años", font=("Arial", 14, "bold"), background="#ddeeff")
        self.lbl_edad.pack(pady=10)
        
        self.lbl_imagen = ttk.Label(self.frame)
        self.lbl_imagen.pack(pady=20)
        
        self.entry_respuesta = ttk.Entry(self.frame, font=("Arial", 14))
        self.entry_respuesta.pack(pady=10)
        
        self.btn_validar = ttk.Button(self.frame, text="Validar Respuesta", command=self.validar_respuesta, style="TButton")
        self.btn_validar.pack(pady=10)
        
        self.btn_regresar = ttk.Button(self.frame, text="Regresar", command=self.regresar_pregunta, style="TButton")
        self.btn_regresar.pack(pady=10)
        
        self.lbl_resultado = ttk.Label(self.frame, text="", font=("Arial", 14, "bold"), background="#ddeeff")
        self.lbl_resultado.pack(pady=10)

    def mostrar_pregunta(self):
        if self.indice_pregunta < len(self.preguntas):
            pregunta_actual = self.preguntas[self.indice_pregunta]
            
            ruta_imagen = obtener_ruta_imagen(pregunta_actual["imagen"])
            if ruta_imagen:
                imagen = Image.open(ruta_imagen)
                imagen = imagen.resize((440, 440), Image.LANCZOS)
                self.img_tk = ImageTk.PhotoImage(imagen)
                self.lbl_imagen.config(image=self.img_tk)
            else:
                self.lbl_imagen.config(text="Imagen no encontrada", font=("Arial", 14, "bold"))
            
            self.entry_respuesta.delete(0, tk.END)
            self.lbl_resultado.config(text="")
        else:
            self.finalizar_test()

    def validar_respuesta(self):
        respuesta_usuario = self.entry_respuesta.get().strip().upper()
        
        if not respuesta_usuario:
            self.lbl_resultado.config(text="Respuesta vacía, intenta de nuevo", foreground="red")
            return
        
        pregunta_actual = self.preguntas[self.indice_pregunta]
        respuesta_correcta = pregunta_actual["respuesta"]
        numero_pregunta = pregunta_actual["imagen"].split(".")[0]  # Extrae el número de la pregunta
        estado = "Correcto" if respuesta_usuario == respuesta_correcta else "Incorrecto"
        self.lbl_resultado.config(text=estado, foreground="green" if estado == "Correcto" else "red")
        
        self.respuestas_usuario.append({
            "pregunta": numero_pregunta,
            "respuesta_correcta": respuesta_correcta,
            "respuesta_usuario": respuesta_usuario,
            "estado": estado
        })
        
        self.indice_pregunta += 1
        self.root.after(1000, self.mostrar_pregunta)
    
    def regresar_pregunta(self):
        if self.indice_pregunta > 0:
            self.indice_pregunta -= 1
            if self.respuestas_usuario:
                self.respuestas_usuario.pop()
            self.mostrar_pregunta()

    def finalizar_test(self):
        self.lbl_imagen.config(image="", text="Test finalizado.")
        
        ttk.Label(self.frame, text="Observaciones:", font=("Arial", 12, "bold"), background="#ddeeff").pack(pady=5)
        self.entry_observaciones = ttk.Entry(self.frame, font=("Arial", 14), width=50)
        self.entry_observaciones.pack(pady=10)

        self.btn_guardar_pdf = ttk.Button(self.frame, text="Guardar Resultados en PDF", command=self.guardar_pdf, style="TButton")
        self.btn_guardar_pdf.pack(pady=10)

        self.btn_finalizar = ttk.Button(self.frame, text="Finalizar", command=self.root.destroy, style="TButton")
        self.btn_finalizar.pack(pady=10)
        
        self.entry_respuesta.pack_forget()
        self.btn_validar.pack_forget()
        self.btn_regresar.pack_forget()
        self.lbl_resultado.pack_forget()
        
        self.guardar_resultados()
        self.mostrar_resumen()

    def guardar_pdf(self):
        with open(RESULTADOS_JSON, "r") as archivo:
            datos = json.load(archivo)
        nombre_estudiante = datos.get("Datos del Examinado", {}).get("Nombre", "resultado")
        apellido_estudiante = datos.get("Datos del Examinado", {}).get("Apellidos", "")
        fecha_actual = datetime.today().strftime('%Y-%m-%d')
        nombre_predeterminado = f"{nombre_estudiante}_{apellido_estudiante}_{fecha_actual}.pdf".replace(" ", "_")
        
        ruta_archivo = filedialog.asksaveasfilename(
            defaultextension=".pdf",
            filetypes=[("PDF files", "*.pdf")],
            initialfile=nombre_predeterminado
        )

        if ruta_archivo:
            guardarPDF.generar_pdf(ruta_archivo)  # Pasa la ruta aquí
            messagebox.showinfo("PDF Generado", f"El PDF se ha guardado correctamente en:\n{ruta_archivo}")



    def guardar_resultados(self):
        datos_existentes = {}
        
        # Cargar los datos existentes del JSON sin eliminarlos
        if os.path.exists(RESULTADOS_JSON):
            with open(RESULTADOS_JSON, "r") as archivo:
                try:
                    datos_existentes = json.load(archivo)
                except json.JSONDecodeError:
                    datos_existentes = {}

        # Agregar o actualizar respuestas del subtest matrices sin eliminar los otros datos
        datos_existentes["respuestas_subtestMatrices"] = self.respuestas_usuario
        datos_existentes["resumen_subtestMatrices"] = {
            "correctas": sum(1 for r in self.respuestas_usuario if r["estado"] == "Correcto"),
            "incorrectas": len(self.respuestas_usuario) - sum(1 for r in self.respuestas_usuario if r["estado"] == "Correcto")
        }

        # Guardar el JSON actualizado sin borrar los otros datos
        with open(RESULTADOS_JSON, "w") as archivo:
            json.dump(datos_existentes, archivo, indent=4)



if __name__ == "__main__":
    root = tk.Tk()
    app = InterfazSubtestMatrices(root, edad=4)
    root.mainloop()
