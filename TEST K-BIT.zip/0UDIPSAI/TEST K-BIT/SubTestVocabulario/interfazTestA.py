import tkinter as tk
from tkinter import ttk, messagebox
from configTestA import obtener_preguntas_por_edad, obtener_ruta_imagen
from PIL import Image, ImageTk
import json
import os
from interfazTestB import InterfazTestB

# Constante que define el nombre del archivo JSON donde se guardarán los resultados
RESULTADOS_JSON = "resultados.json"

class InterfazTestA:
    def __init__(self, root, edad):
        """
        Inicializa la interfaz del Test A.
        
        :param root: La ventana principal de la aplicación.
        :param edad: La edad del examinado, que determina las preguntas a mostrar.
        """
        self.root = root
        self.root.title("Test K-BIT - Subtest A")  # Título de la ventana
        self.root.geometry("1000x700")  # Tamaño inicial de la ventana
        self.root.state('zoomed')  # Maximiza la ventana al iniciar
        self.root.configure(bg="#ddeeff")  # Color de fondo de la ventana
        self.edad = edad  # Edad del examinado
        self.secciones = obtener_preguntas_por_edad(edad)  # Obtiene las preguntas según la edad
        self.seccion_actual = 0  # Índice de la sección actual
        self.indice_pregunta = 0  # Índice de la pregunta actual dentro de la sección
        self.errores_seccion = 0  # Contador de errores en la sección actual
        self.aciertos_seccion = 0  # Contador de aciertos en la sección actual
        self.respuestas = []  # Lista para almacenar las respuestas del usuario
        
        self.crear_interfaz()  # Crea la interfaz gráfica
        self.mostrar_pregunta()  # Muestra la primera pregunta

    def crear_interfaz(self):
        """
        Crea los elementos de la interfaz gráfica.
        """
        self.frame = ttk.Frame(self.root, padding=20, relief="ridge", borderwidth=2, style="TFrame")
        self.frame.place(relx=0.5, rely=0.5, anchor=tk.CENTER)  # Centra el frame en la ventana
        
        # Etiqueta que muestra la edad del examinado
        self.lbl_edad = ttk.Label(self.frame, text=f"Edad: {self.edad} años", font=("Arial", 14, "bold"), background="#ddeeff")
        self.lbl_edad.pack(pady=10)
        
        # Etiqueta para mostrar la imagen de la pregunta
        self.lbl_imagen = ttk.Label(self.frame)
        self.lbl_imagen.pack(pady=20)
        
        # Entrada de texto para que el usuario ingrese su respuesta
        self.entry_respuesta = ttk.Entry(self.frame, font=("Arial", 14))
        self.entry_respuesta.pack(pady=10)
        
        # Botón para validar la respuesta del usuario
        self.btn_validar = ttk.Button(self.frame, text="Validar Respuesta", command=self.validar_respuesta, style="TButton")
        self.btn_validar.pack(pady=10)
        
        # Botón para regresar a la pregunta anterior
        self.btn_regresar = ttk.Button(self.frame, text="Regresar", command=self.regresar_pregunta, style="TButton")
        self.btn_regresar.pack(pady=10)

    def mostrar_pregunta(self):
        """
        Muestra la pregunta actual o avanza a la siguiente sección si es necesario.
        """
        if self.seccion_actual < len(self.secciones):  # Verifica si hay más secciones
            preguntas_seccion = self.secciones[self.seccion_actual]  # Obtiene las preguntas de la sección actual
            
            if self.indice_pregunta < len(preguntas_seccion):  # Verifica si hay más preguntas en la sección
                pregunta = preguntas_seccion[self.indice_pregunta]  # Obtiene la pregunta actual

                ruta_imagen = obtener_ruta_imagen(pregunta)  # Obtiene la ruta de la imagen de la pregunta
                if ruta_imagen:
                    imagen = Image.open(ruta_imagen)  # Abre la imagen
                    imagen = imagen.resize((400, 400), Image.LANCZOS)  # Redimensiona la imagen
                    self.img_tk = ImageTk.PhotoImage(imagen)  # Convierte la imagen a formato Tkinter
                    self.lbl_imagen.config(image=self.img_tk)  # Muestra la imagen en la etiqueta
                else:
                    self.lbl_imagen.config(text="Imagen no encontrada", font=("Arial", 14, "bold"))

                self.entry_respuesta.delete(0, tk.END)  # Limpia la entrada de texto
            else:
                self.revisar_seccion()  # Si no hay más preguntas, revisa la sección
        else:
            self.finalizar_test()  # Si no hay más secciones, finaliza el test

    def validar_respuesta(self):
        """
        Valida la respuesta del usuario y decide si avanzar a la siguiente pregunta o finalizar la sección.
        """
        respuesta_usuario = self.entry_respuesta.get().strip().lower()  # Obtiene la respuesta del usuario

        if not respuesta_usuario:  # Verifica si la respuesta está vacía
            messagebox.showerror("Error", "Respuesta vacía, intenta de nuevo")
            return

        pregunta_actual = self.secciones[self.seccion_actual][self.indice_pregunta]  # Obtiene la pregunta actual
        respuesta_correcta = pregunta_actual.lower()  # Obtiene la respuesta correcta en minúsculas
        estado = "Correcto" if respuesta_usuario == respuesta_correcta else "Incorrecto"  # Determina si la respuesta es correcta

        if estado == "Correcto":
            self.aciertos_seccion += 1  # Incrementa el contador de aciertos
        else:
            self.errores_seccion += 1  # Incrementa el contador de errores

        # Guarda la respuesta del usuario
        self.respuestas.append({
            "pregunta": pregunta_actual,
            "respuesta": respuesta_usuario,
            "estado": estado
        })

        self.indice_pregunta += 1  # Avanza a la siguiente pregunta
        self.mostrar_pregunta()  # Muestra la siguiente pregunta

    def regresar_pregunta(self):
        """
        Permite regresar a la pregunta anterior.
        """
        if self.indice_pregunta > 0:  # Verifica si hay una pregunta anterior
            self.indice_pregunta -= 1  # Retrocede al índice de la pregunta anterior
            if self.respuestas:
                self.respuestas.pop()  # Elimina la última respuesta del usuario
            self.mostrar_pregunta()  # Muestra la pregunta anterior

    def revisar_seccion(self):
        """
        Revisa si se deben avanzar a la siguiente sección o finalizar el test.
        """
        if self.errores_seccion >= 5:  # Si hay 5 o más errores en la sección, finaliza el test
            self.finalizar_test()
        else:
            self.seccion_actual += 1  # Avanza a la siguiente sección
            self.indice_pregunta = 0  # Reinicia el índice de la pregunta
            self.errores_seccion = 0  # Reinicia el contador de errores
            self.aciertos_seccion = 0  # Reinicia el contador de aciertos
            self.mostrar_pregunta()  # Muestra la primera pregunta de la nueva sección

    def finalizar_test(self):
        """
        Finaliza el test y muestra el resumen.
        """
        self.lbl_imagen.config(image="", text="Test finalizado.")  # Limpia la imagen y muestra mensaje de finalización
        self.entry_respuesta.pack_forget()  # Oculta la entrada de texto
        self.btn_validar.pack_forget()  # Oculta el botón de validar
        self.btn_regresar.pack_forget()  # Oculta el botón de regresar

        self.guardar_resultados()  # Guarda los resultados en el archivo JSON
        self.mostrar_resumen()  # Muestra el resumen de respuestas correctas e incorrectas

    def guardar_resultados(self):
        """
        Guarda los resultados del test en el archivo JSON.
        """
        if os.path.exists(RESULTADOS_JSON):  # Verifica si el archivo JSON ya existe
            with open(RESULTADOS_JSON, "r") as archivo:
                try:
                    datos_existentes = json.load(archivo)  # Carga los datos existentes
                except json.JSONDecodeError:
                    datos_existentes = {}  # Si hay un error, inicializa un diccionario vacío
        else:
            datos_existentes = {}  # Si el archivo no existe, inicializa un diccionario vacío

        # Guarda las respuestas y el resumen del Test A
        datos_existentes.setdefault("respuestas_testA", []).extend(self.respuestas)
        datos_existentes["resumen_testA"] = {
            "correctas": sum(1 for r in self.respuestas if r["estado"] == "Correcto"),
            "incorrectas": len(self.respuestas) - sum(1 for r in self.respuestas if r["estado"] == "Correcto")
        }

        with open(RESULTADOS_JSON, "w") as archivo:
            json.dump(datos_existentes, archivo, indent=4)  # Guarda los datos en el archivo JSON

    def mostrar_resumen(self):
        """
        Muestra un resumen de las respuestas correctas e incorrectas.
        """
        correctas = sum(1 for r in self.respuestas if r["estado"] == "Correcto")  # Cuenta las respuestas correctas
        incorrectas = len(self.respuestas) - correctas  # Cuenta las respuestas incorrectas

        resumen = f"Respuestas Correctas: {correctas}\nRespuestas Incorrectas: {incorrectas}"  # Crea el texto del resumen
        self.lbl_resumen = ttk.Label(self.frame, text=resumen, font=("Arial", 14, "bold"), background="#ddeeff")
        self.lbl_resumen.pack(pady=10)  # Muestra el resumen en la interfaz

        # Etiqueta y entrada para observaciones
        ttk.Label(self.frame, text="Observaciones:", font=("Arial", 12, "bold"), background="#ddeeff").pack(pady=5)
        self.entry_observaciones = ttk.Entry(self.frame, font=("Arial", 14), width=50)
        self.entry_observaciones.pack(pady=10)
        
        # Botón para avanzar al siguiente test
        self.btn_guardar_observaciones = ttk.Button(self.frame, text="Avanzar al siguiente test", command=self.avanzar_siguiente_test, style="TButton")
        self.btn_guardar_observaciones.pack(pady=10)

    def avanzar_siguiente_test(self):
        """
        Guarda las observaciones y avanza al siguiente test según la edad del examinado.
        """
        observaciones = self.entry_observaciones.get().strip()  # Obtiene las observaciones
        if observaciones:
            with open(RESULTADOS_JSON, "r+") as archivo:
                datos = json.load(archivo)
                datos["observaciones_testA"] = observaciones  # Guarda las observaciones en el JSON
                archivo.seek(0)
                json.dump(datos, archivo, indent=4)

        for widget in self.root.winfo_children():
            widget.destroy()  # Limpia la ventana actual

        if self.edad >= 8:
            InterfazTestB(self.root, self.edad)  # Si es mayor o igual a 8 años, va al Test B
        else:
            from interfazSubtestMatrices import InterfazSubtestMatrices
            InterfazSubtestMatrices(self.root, self.edad)  # Si es menor de 8 años, va directo a Matrices

    def guardar_observaciones(self):
        """
        Guarda las observaciones en el archivo JSON.
        """
        observaciones = self.entry_observaciones.get().strip()  # Obtiene las observaciones
        if observaciones:
            with open(RESULTADOS_JSON, "r+") as archivo:
                datos = json.load(archivo)
                datos["observaciones_testA"] = observaciones  # Guarda las observaciones en el JSON
                archivo.seek(0)
                json.dump(datos, archivo, indent=4)
            messagebox.showinfo("Guardado", "Observaciones guardadas correctamente.")  # Muestra un mensaje de confirmación


if __name__ == "__main__":
    root = tk.Tk()  # Crea la ventana principal
    app = InterfazTestA(root, edad=10)  # Inicia la aplicación con la edad 10
    root.mainloop()  # Ejecuta el bucle principal de la interfaz gráfica