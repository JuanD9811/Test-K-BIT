import os

# Preguntas organizadas en secciones de 5 preguntas
PREGUNTAS_SECCIONES = [
    ["Cama", "Tenedor", "Rana", "Escalera", "Humo"],  # Sección 0
    ["Paraguas", "Piano", "Hoja", "Tambor", "Autobus"],  # Sección 1
    ["Martillo", "Fuente", "Buho", "Lampara", "Pinguino"],  # Sección 2
    ["Pluma", "Linterna", "Ventana", "Regla", "Tornillo"],  # Sección 3
    ["Puente", "Lupa", "Grapadora", "Calendario", "Prismaticos"],  # Sección 4
    ["Cactus", "Cangrejo", "Candado", "Buzon", "Pinzas"],  # Sección 5
    ["Ancla", "Enchufe", "Calculadora", "Anzuelo", "Silla montar"],  # Sección 6
    ["Escalera Mecanica", "Embudo", "Compas", "Saltamontes", "Balanza"],  # Sección 7
    ["Microscopio", "Extintor", "Hexagono", "Yunque", "Salvavidas"]  # Sección 8
]

# Diccionario de edad a sección inicial
SECCION_INICIAL_POR_EDAD = {
    (4, 5): 0,
    (6, 6): 1,
    (7, 7): 2,
    (8, 8): 3,
    (9, 10): 4,  
    (11, 12): 5,
    (13, 90): 6
}

# Ruta de imágenes
IMAGENES_DIR = os.path.abspath(r"C:\Users\juan_\Dropbox\PC\Documents\0UDIPSAI\TEST K-BIT\Imagenes\Vocabulario Expresivo")

def obtener_preguntas_por_edad(edad):
    """
    Devuelve una lista de todas las preguntas desde la sección correspondiente a la edad.
    """
    for rango, seccion_inicio in SECCION_INICIAL_POR_EDAD.items():
        if rango[0] <= edad <= rango[1]:
            return PREGUNTAS_SECCIONES[seccion_inicio:]  # Devuelve solo las secciones desde la inicial
    return []

def obtener_ruta_imagen(pregunta):
    """
    Devuelve la ruta de la imagen correspondiente a la pregunta.
    """
    nombre_archivo = pregunta.lower().replace(" ", "_") + ".jpg"
    ruta = os.path.join(IMAGENES_DIR, nombre_archivo)
    return ruta if os.path.exists(ruta) else None
