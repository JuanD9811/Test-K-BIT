import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from configSubtestMatrices import obtener_preguntas_matrices, obtener_ruta_imagen, SECCIONES_MATRICES
from PIL import Image, ImageTk
import json
import os
import guardarPDF
from datetime import datetime

# Constante que define el nombre del archivo JSON donde se guardarán los resultados
RESULTADOS_JSON = "resultados.json"

class InterfazSubtestMatrices:
    def __init__(self, root, edad):
        """
        Inicializa la interfaz del subtest de matrices.
        
        :param root: La ventana principal de la aplicación.
        :param edad: La edad del examinado, que determina las preguntas a mostrar.
        """
        self.root = root
        self.root.title("Test K-BIT - Subtest Matrices")  # Título de la ventana
        self.root.geometry("1000x700")  # Tamaño inicial de la ventana
        self.root.state('zoomed')  # Maximiza la ventana al iniciar
        self.root.configure(bg="#ddeeff")  # Color de fondo de la ventana
        self.edad = edad  # Edad del examinado
        # Obtiene las preguntas, la sección inicial y el índice de la pregunta actual
        self.preguntas, self.seccion_inicio, self.indice_pregunta = obtener_preguntas_matrices(edad)
        self.respuestas_usuario = []  # Lista para almacenar las respuestas del usuario
        self.errores_seccion_actual = 0  # Contador de errores en la sección actual
        self.aciertos_seccion_actual = 0  # Contador de aciertos en la sección actual
        self.seccion_actual = self.seccion_inicio  # Inicia en la sección correspondiente
        
        self.crear_interfaz()  # Crea la interfaz gráfica
        self.mostrar_pregunta()  # Muestra la primera pregunta o ejemplo

    def crear_interfaz(self):
        """
        Crea los elementos de la interfaz gráfica.
        """
        self.frame = ttk.Frame(self.root, padding=20, relief="ridge", borderwidth=2, style="TFrame")
        self.frame.place(relx=0.5, rely=0.5, anchor=tk.CENTER)  # Centra el frame en la ventana
        
        # Etiqueta que muestra la edad del examinado
        self.lbl_edad = ttk.Label(self.frame, text=f"Edad: {self.edad} años", font=("Arial", 14, "bold"), background="#ddeeff")
        self.lbl_edad.pack(pady=10)
        
        # Etiqueta para mostrar la imagen de la pregunta
        self.lbl_imagen = ttk.Label(self.frame)
        self.lbl_imagen.pack(pady=20)
        
        # Entrada de texto para que el usuario ingrese su respuesta
        self.entry_respuesta = ttk.Entry(self.frame, font=("Arial", 14))
        self.entry_respuesta.pack(pady=10)
        
        # Botón para validar la respuesta del usuario
        self.btn_validar = ttk.Button(self.frame, text="Validar Respuesta", command=self.validar_respuesta, style="TButton")
        self.btn_validar.pack(pady=10)
        
        # Botón para regresar a la pregunta anterior
        self.btn_regresar = ttk.Button(self.frame, text="Regresar", command=self.regresar_pregunta, style="TButton")
        self.btn_regresar.pack(pady=10)
        
        # Etiqueta para mostrar el resultado de la validación de la respuesta
        self.lbl_resultado = ttk.Label(self.frame, text="", font=("Arial", 14, "bold"), background="#ddeeff")
        self.lbl_resultado.pack(pady=10)

    def mostrar_ejemplo(self, imagen_ejemplo):
        """
        Muestra un ejemplo con la imagen proporcionada.
        
        :param imagen_ejemplo: Nombre del archivo de la imagen del ejemplo.
        """
        ruta_imagen = obtener_ruta_imagen(imagen_ejemplo)
        if ruta_imagen:
            imagen = Image.open(ruta_imagen)
            imagen = imagen.resize((440, 440), Image.LANCZOS)  # Redimensiona la imagen
            self.img_tk = ImageTk.PhotoImage(imagen)  # Convierte la imagen a formato Tkinter
            self.lbl_imagen.config(image=self.img_tk)  # Muestra la imagen en la etiqueta
        else:
            self.lbl_imagen.config(text="Imagen no encontrada", font=("Arial", 14, "bold"))

        self.entry_respuesta.delete(0, tk.END)  # Limpia la entrada de texto
        self.lbl_resultado.config(text="Este es un ejemplo. No cuenta como respuesta correcta o incorrecta.")

    def mostrar_pregunta(self):
        """
        Muestra la pregunta actual de la sección o el ejemplo correspondiente.
        """
        # Verificar si estamos en la Sección 1 y mostrar el Ejemplo A antes
        if self.seccion_actual == 1 and not hasattr(self, 'ejemplo_a_mostrado'):
            self.mostrar_ejemplo("ejemploA.jpg")
            self.ejemplo_a_mostrado = True  # Marcar que el Ejemplo A ya se mostró
            return  # Salir de la función para no mostrar la pregunta aún

        # Verificar si estamos en la Sección 3 y mostrar el Ejemplo B antes
        if self.seccion_actual == 3 and not hasattr(self, 'ejemplo_b_mostrado'):
            self.mostrar_ejemplo("ejemploB.jpg")
            self.ejemplo_b_mostrado = True  # Marcar que el Ejemplo B ya se mostró
            return  # Salir de la función para no mostrar la pregunta aún

        # Si no es un ejemplo, mostrar la pregunta normal
        if self.indice_pregunta < len(self.preguntas):
            pregunta_actual = self.preguntas[self.indice_pregunta]
            ruta_imagen = obtener_ruta_imagen(pregunta_actual["imagen"])
            if ruta_imagen:
                imagen = Image.open(ruta_imagen)
                imagen = imagen.resize((440, 440), Image.LANCZOS)  # Redimensiona la imagen
                self.img_tk = ImageTk.PhotoImage(imagen)  # Convierte la imagen a formato Tkinter
                self.lbl_imagen.config(image=self.img_tk)  # Muestra la imagen en la etiqueta
            else:
                self.lbl_imagen.config(text="Imagen no encontrada", font=("Arial", 14, "bold"))

            self.entry_respuesta.delete(0, tk.END)  # Limpia la entrada de texto
            self.lbl_resultado.config(text="")  # Limpia el mensaje de resultado
        else:
            self.finalizar_test()  # Si no hay más preguntas, finaliza el test

    def validar_respuesta(self):
        """
        Valida la respuesta del usuario y decide si continuar o finalizar la sección.
        """
        # Si estamos en un ejemplo, no validar la respuesta
        if (self.seccion_actual == 1 and not hasattr(self, 'ejemplo_a_mostrado')) or \
        (self.seccion_actual == 3 and not hasattr(self, 'ejemplo_b_mostrado')):
            self.mostrar_pregunta()  # Mostrar la siguiente pregunta o ejemplo
            return  # Salir de la función sin validar la respuesta

        respuesta_usuario = self.entry_respuesta.get().strip().upper()  # Obtiene la respuesta del usuario
        if not respuesta_usuario:
            self.lbl_resultado.config(text="Respuesta vacía, intenta de nuevo", foreground="red")
            return

        pregunta_actual = self.preguntas[self.indice_pregunta]
        respuesta_correcta = pregunta_actual["respuesta"]
        numero_pregunta = int(pregunta_actual["imagen"].split(".")[0])  # Obtener número de la pregunta

        # Determinar la sección actual
        for seccion, (inicio, fin) in SECCIONES_MATRICES.items():
            if inicio <= numero_pregunta <= fin:
                self.seccion_actual = seccion
                inicio_seccion, fin_seccion = inicio, fin
                break

        estado = "Correcto" if respuesta_usuario == respuesta_correcta else "Incorrecto"
        self.respuestas_usuario.append({
            "pregunta": str(numero_pregunta),
            "respuesta_correcta": respuesta_correcta,
            "respuesta_usuario": respuesta_usuario,
            "estado": estado,
            "seccion": self.seccion_actual
        })

        # Contar aciertos y errores en la sección
        if estado == "Incorrecto":
            self.errores_seccion_actual += 1
        else:
            self.aciertos_seccion_actual += 1

        print(f"Sección: {self.seccion_actual}, Pregunta: {numero_pregunta}, Estado: {estado}")
        print(f"Aciertos: {self.aciertos_seccion_actual}, Errores: {self.errores_seccion_actual}")

        # Avanzar a la siguiente pregunta
        self.indice_pregunta += 1

        # Verificar si quedan preguntas en la sección actual
        if self.indice_pregunta <= fin_seccion:
            self.mostrar_pregunta()
            return  # No salir de la función, seguir mostrando preguntas

        # Si termina la sección, decidir si avanzar o finalizar
        if self.aciertos_seccion_actual > 0:
            # Si hay al menos un acierto, avanzar a la siguiente sección
            print(f"Avanzando a la siguiente sección (de {self.seccion_actual} a {self.seccion_actual + 1})")
            self.seccion_actual += 1
            self.aciertos_seccion_actual = 0  # Reiniciar contador de aciertos
            self.errores_seccion_actual = 0   # Reiniciar contador de errores

            if self.seccion_actual in SECCIONES_MATRICES:
                self.indice_pregunta = SECCIONES_MATRICES[self.seccion_actual][0]  # Primera pregunta de la nueva sección
                self.mostrar_pregunta()
            else:
                print("No hay más secciones, finalizando el test.")
                self.finalizar_test()
        else:
            # Si no hubo aciertos en la sección, finalizar test
            print(f"Finalizando test porque no hubo aciertos en la sección {self.seccion_actual}.")
            self.finalizar_test()

    def regresar_pregunta(self):
        """
        Permite regresar a la pregunta anterior.
        """
        if self.indice_pregunta > 0:
            self.indice_pregunta -= 1
            if self.respuestas_usuario:
                self.respuestas_usuario.pop()  # Elimina la última respuesta del usuario
            self.mostrar_pregunta()  # Muestra la pregunta anterior

    def finalizar_test(self):
        """
        Finaliza el test y muestra el resumen.
        """
        self.lbl_imagen.config(image="", text="Test finalizado.")  # Limpia la imagen y muestra mensaje de finalización

        # Etiqueta y entrada para observaciones
        ttk.Label(self.frame, text="Observaciones:", font=("Arial", 12, "bold"), background="#ddeeff").pack(pady=5)
        self.entry_observaciones = ttk.Entry(self.frame, font=("Arial", 14), width=50)
        self.entry_observaciones.pack(pady=10)

        # Botón para guardar los resultados en PDF
        self.btn_guardar_pdf = ttk.Button(self.frame, text="Guardar Resultados en PDF", command=self.guardar_pdf, style="TButton")
        self.btn_guardar_pdf.pack(pady=10)

        # Botón para finalizar la aplicación
        self.btn_finalizar = ttk.Button(self.frame, text="Finalizar", command=self.root.destroy, style="TButton")
        self.btn_finalizar.pack(pady=10)
        
        # Oculta elementos que ya no son necesarios
        self.entry_respuesta.pack_forget()
        self.btn_validar.pack_forget()
        self.btn_regresar.pack_forget()
        self.lbl_resultado.pack_forget()
        
        self.guardar_resultados()  # Guarda los resultados en el archivo JSON
        self.mostrar_resumen()  # Muestra el resumen de respuestas correctas e incorrectas

    def guardar_pdf(self):
        """
        Guarda los resultados en un archivo PDF.
        """
        observaciones = self.entry_observaciones.get().strip()
        if observaciones:
            self.guardar_observaciones(observaciones)  # Guarda las observaciones en el JSON

        with open(RESULTADOS_JSON, "r") as archivo:
            datos = json.load(archivo)
        nombre_estudiante = datos.get("Datos del Examinado", {}).get("Nombre", "resultado")
        apellido_estudiante = datos.get("Datos del Examinado", {}).get("Apellidos", "")
        fecha_actual = datetime.today().strftime('%Y-%m-%d')
        nombre_predeterminado = f"{nombre_estudiante}_{apellido_estudiante}_{fecha_actual}.pdf".replace(" ", "_")
        
        # Diálogo para guardar el archivo PDF
        ruta_archivo = filedialog.asksaveasfilename(
            defaultextension=".pdf",
            filetypes=[("PDF files", "*.pdf")],
            initialfile=nombre_predeterminado
        )

        if ruta_archivo:
            guardarPDF.generar_pdf(ruta_archivo)  # Genera el PDF
            messagebox.showinfo("PDF Generado", f"El PDF se ha guardado correctamente en:\n{ruta_archivo}")

    def guardar_observaciones(self, observaciones):
        """
        Guarda las observaciones en el archivo JSON.
        
        :param observaciones: Texto de las observaciones a guardar.
        """
        datos_existentes = {}
        
        if os.path.exists(RESULTADOS_JSON):
            with open(RESULTADOS_JSON, "r") as archivo:
                try:
                    datos_existentes = json.load(archivo)
                except json.JSONDecodeError:
                    datos_existentes = {}

        datos_existentes["observaciones_subtestMatrices"] = observaciones

        with open(RESULTADOS_JSON, "w") as archivo:
            json.dump(datos_existentes, archivo, indent=4)

    def guardar_resultados(self):
        """
        Guarda los resultados del test en el archivo JSON.
        """
        datos_existentes = {}

        if os.path.exists(RESULTADOS_JSON):
            with open(RESULTADOS_JSON, "r") as archivo:
                try:
                    datos_existentes = json.load(archivo)
                except json.JSONDecodeError:
                    datos_existentes = {}

        datos_existentes.setdefault("Datos del Examinado", datos_existentes.get("Datos del Examinado", {}))
        datos_existentes.setdefault("respuestas_testA", datos_existentes.get("respuestas_testA", []))
        datos_existentes.setdefault("resumen_testA", datos_existentes.get("resumen_testA", {"correctas": 0, "incorrectas": 0}))
        datos_existentes.setdefault("respuestas_testB", datos_existentes.get("respuestas_testB", []))
        datos_existentes.setdefault("resumen_testB", datos_existentes.get("resumen_testB", {"correctas": 0, "incorrectas": 0}))

        datos_existentes["respuestas_subtestMatrices"] = self.respuestas_usuario
        datos_existentes["resumen_subtestMatrices"] = {
            "correctas": sum(1 for r in self.respuestas_usuario if r["estado"] == "Correcto"),
            "incorrectas": len(self.respuestas_usuario) - sum(1 for r in self.respuestas_usuario if r["estado"] == "Correcto")
        }

        with open(RESULTADOS_JSON, "w") as archivo:
            json.dump(datos_existentes, archivo, indent=4)

    def mostrar_resumen(self):
        """
        Muestra un resumen de las respuestas correctas e incorrectas.
        """
        correctas = sum(1 for r in self.respuestas_usuario if r["estado"] == "Correcto")
        incorrectas = len(self.respuestas_usuario) - correctas
        
        resumen = f"Respuestas Correctas: {correctas}\nRespuestas Incorrectas: {incorrectas}"
        self.lbl_resumen = ttk.Label(self.frame, text=resumen, font=("Arial", 14, "bold"), background="#ddeeff")
        self.lbl_resumen.pack(pady=10)


if __name__ == "__main__":
    root = tk.Tk()  # Crea la ventana principal
    app = InterfazSubtestMatrices(root, edad=4)  # Inicia la aplicación con la edad 4
    root.mainloop()  # Ejecuta el bucle principal de la interfaz gráfica