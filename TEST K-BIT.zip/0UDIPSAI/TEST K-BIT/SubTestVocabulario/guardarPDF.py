from fpdf import FPDF
import json
import os

RESULTADOS_JSON = "resultados.json"
LOGO_PATH = r"C:\Users\juan_\Dropbox\PC\Documents\0UDIPSAI\TEST K-BIT\Imagenes\UDIPSAI.jpg"

def generar_pdf(ruta_pdf=None):
    with open(RESULTADOS_JSON, "r") as archivo:
        datos = json.load(archivo)
    
    pdf = FPDF()
    pdf.set_auto_page_break(auto=True, margin=15)
    pdf.add_page()
    
    # Logo alineado a la derecha
    if os.path.exists(LOGO_PATH):
        pdf.image(LOGO_PATH, x=160, y=8, w=30)
    pdf.set_font("Arial", "B", 16)
    pdf.cell(200, 10, "Resultados del Test K-BIT", ln=True, align="C")
    pdf.ln(20)
    
    # Datos del examinado
    pdf.set_font("Arial", "B", 12)
    pdf.cell(200, 10, "Datos del Examinado:", ln=True)
    pdf.set_font("Arial", "", 10)
    for key, value in datos.get("Datos del Examinado", {}).items():
        pdf.cell(200, 8, f"{key}: {value}", ln=True)
    pdf.ln(5)
    
    # Orden de subtests
    subtests_ordenados = [
        ("respuestas_testA", "Subtest1 VOCABULARIO: Parte A Vocabulario Expresivo"),
        ("respuestas_testB", "Subtest1 VOCABULARIO: Parte B Definiciones"),
        ("respuestas_subtestMatrices", "Subtest2: MATRICES")
    ]
    
    for clave, titulo in subtests_ordenados:
        if clave in datos:
            pdf.set_font("Arial", "B", 12)
            pdf.cell(200, 10, titulo, ln=True)
            pdf.set_font("Arial", "", 10)
            for idx, r in enumerate(datos[clave], start=1):
                pdf.set_font("Arial", "B", 10)
                pdf.cell(200, 8, f"Pregunta {idx}", ln=True)
                pdf.set_font("Arial", "", 10)
                pdf.cell(200, 8, f"   Respuesta Correcta: {r.get('respuesta_correcta', r.get('pregunta', r.get('imagen', 'No definida')))}", ln=True)
                pdf.cell(200, 8, f"   Respuesta: {r.get('respuesta', r.get('respuesta_usuario', 'No respondida'))}", ln=True)
                
                if r.get('estado', 'N/A') == 'Correcto':
                    pdf.set_text_color(0, 128, 0)
                else:
                    pdf.set_text_color(255, 0, 0)
                
                pdf.cell(200, 8, f"   Estado: {r.get('estado', 'N/A')}", ln=True)
                pdf.set_text_color(0, 0, 0)
            pdf.ln(10)
            
            # Observaciones al final de cada subtest
            observaciones_key = f"observaciones_{clave.split('_')[-1]}"
            if observaciones_key in datos:
                pdf.set_font("Arial", "B", 12)
                pdf.cell(200, 10, "Observaciones:", ln=True)
                pdf.set_font("Arial", "", 10)
                pdf.multi_cell(0, 8, datos[observaciones_key])
                pdf.ln(10)
            
            # Resultados de cada subtest
            resumen_key = f"resumen_{clave.split('_')[-1]}"
            if resumen_key in datos:
                pdf.set_font("Arial", "B", 12)
                pdf.cell(200, 10, "Resultados del Subtest:", ln=True)
                pdf.set_font("Arial", "", 10)
                resumen = datos[resumen_key]
                pdf.cell(200, 8, f"   Correctas: {resumen.get('correctas', 0)}", ln=True)
                pdf.cell(200, 8, f"   Incorrectas: {resumen.get('incorrectas', 0)}", ln=True)
                pdf.ln(10)
    
    # Guardar PDF en la ubicación especificada
    if ruta_pdf:
        pdf.output(ruta_pdf)
        print(f"PDF guardado en: {ruta_pdf}")
    else:
        pdf.output("resultado_test.pdf")
        print("PDF guardado en: resultado_test.pdf")

if __name__ == "__main__":
    generar_pdf()
