import os

# Diccionario con las respuestas correctas por rango de edad
RESPUESTAS_MATRICES = {
    1: "A", 2: "C", 3: "E", 4: "D", 5: "A", 
    6: "C", 7: "B", 8: "D", 9: "E",
    10: "A", 11: "F", 12: "B", 13: "F", 14: "C", 15: "B", 16: "A", 17: "H", 18: "C", 19: "G", 20: "A", 
    21: "D", 22: "F", 23: "E", 24: "E", 25: "A", 26: "H", 27: "D", 28: "H", 29: "C", 
    30: "F", 31: "B", 32: "G", 33: "G", 34: "G", 35: "C", 36: "E", 37: "C", 38: "D", 
    39: "A", 40: "H", 41: "A", 42: "H", 43: "B", 44: "A", 45: "B", 46: "B", 47: "A", 48: "G"
}

# Definir las secciones por rango de preguntas
SECCIONES_MATRICES = {
    1: (1, 4), 2: (5, 9), 3: (10, 14), 4: (15, 19), 5: (20, 24), 
    6: (25, 29), 7: (30, 34), 8: (35, 39), 9: (40, 44), 10: (45, 48)
}

IMAGENES_DIR = os.path.abspath(r"C:\Users\juan_\Dropbox\PC\Documents\0UDIPSAI\TEST K-BIT\Imagenes\Subtest Matrices")

def obtener_preguntas_matrices(edad):
    preguntas = []
    seccion_inicio = None

    # **Determinar la sección inicial según la edad**
    if 4 <= edad <= 5:
        seccion_inicio = 1  # Edad 4-5 inicia en la sección 1
    elif 6 <= edad <= 10:
        seccion_inicio = 3  # Edad 6-10 inicia en la sección 3
    elif 11 <= edad <= 90:
        seccion_inicio = 4  # Edad 11-90 inicia en la sección 4
    else:
        raise ValueError("Edad no válida. Debe estar entre 4 y 90 años.")

    # **Añadir todas las preguntas**
    for num, respuesta in sorted(RESPUESTAS_MATRICES.items()):
        preguntas.append({"imagen": f"{num}.jpg", "respuesta": respuesta})

    # **Ajustar el índice de la pregunta inicial según la sección**
    inicio, _ = SECCIONES_MATRICES[seccion_inicio]
    indice_pregunta_inicial = inicio - 1  # Ajustar a índice base 0

    return preguntas, seccion_inicio, indice_pregunta_inicial  # Retornar preguntas, sección inicial e índice de la pregunta inicial

def obtener_ruta_imagen(nombre_imagen):
    """Devuelve la ruta de la imagen correspondiente a la pregunta."""
    ruta = os.path.join(IMAGENES_DIR, nombre_imagen)
    return ruta if os.path.exists(ruta) else None