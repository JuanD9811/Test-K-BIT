import os

EJEMPLOS = ["NEGRO", "ANTIGUO"]

# Diccionario con las respuestas correctas organizadas por secciones
RESPUESTAS_POR_SECCION = {
    1: ["JARDIN", "AMANECER", "ARAR", "GRANIZO", "DELICIOSO"],
    2: ["VENTANA", "LIO", "ESQUIMAL", "PRIMO/PRIMA", "ESCRIBIR"],
    3: ["AGRADECER", "EXPERIMENTO", "CORDIAL", "PRESCINDIR", "SIMPATICO"],
    4: ["CARICATURA", "RENCOR", "ATENTADO", "SUFICIENTE", "ENERGIA"],
    5: ["ELEVADO", "INFORTUNADO", "HIPOCONDRIACO", "ESTORBAR", "CONSTANTE"],
    6: ["CONSENTIR", "CONVERSACION", "INSENSATO", "SOBRESALIENTE"],
    7: ["ENMENDAR", "INDELEBLE", "VEROSIMIL", "CLANDESTINO"],
    8: ["PREPOTENTE","CONECTAR","ENIGMA", "FANATICO"]
}

# Asignación de secciones según la edad
INICIO_POR_EDAD = {
    (8, 14): 1,  # De 8 a 14 años inicia en la sección 1
    (15, 90): 2  # De 15 en adelante inicia en la sección 2
}

IMAGENES_DIR = os.path.abspath(r"C:\Users\juan_\Dropbox\PC\Documents\0UDIPSAI\TEST K-BIT\Imagenes\Vocabulario Definiciones")

def obtener_preguntas(edad):
    """
    Devuelve una lista de preguntas y la sección inicial según la edad.
    """
    preguntas = ["NEGRO", "ANTIGUO"]  # Ejemplos obligatorios (NO cuentan como sección)
    inicio_seccion = 1  # Sección inicial por defecto

    # Secciones definidas correctamente
    SECCIONES = {
        1: ["JARDIN", "AMANECER", "ARAR", "GRANIZO", "DELICIOSO"],
        2: ["VENTANA", "LIO", "ESQUIMAL", "PRIMO/PRIMA", "ESCRIBIR"],
        3: ["AGRADECER", "EXPERIMENTO", "CORDIAL", "PRESCINDIR", "SIMPATICO"],
        4: ["CARICATURA", "RENCOR", "ATENTADO", "SUFICIENTE", "ENERGIA"],
        5: ["ELEVADO", "INFORTUNADO", "HIPOCONDRIACO", "ESTORBAR", "CONSTANTE"],
        6: ["CONSENTIR", "CONVERSACION", "INSENSATO", "SOBRESALIENTE"],
        7: ["ENMENDAR", "INDELEBLE", "VEROSIMIL", "CLANDESTINO"],
        8: ["PREPOTENTE", "CONECTAR", "ENIGMA", "FANATICO"]
    }

    # Determinar en qué sección inicia según la edad
    if 8 <= edad <= 14:
        inicio_seccion = 1
    elif 15 <= edad <= 90:
        inicio_seccion = 2

    # Agregar solo las preguntas desde la sección inicial en adelante
    for sec, preguntas_sec in SECCIONES.items():
        if sec >= inicio_seccion:
            preguntas.extend(preguntas_sec)

    return preguntas, inicio_seccion  # Devuelve preguntas + número de sección inicial


def obtener_ruta_imagen(respuesta):
    """
    Devuelve la ruta de la imagen correspondiente a la respuesta.
    Si hay múltiples respuestas separadas por "/", intenta cargar la primera disponible.
    """
    posibles_nombres = [r.lower().replace(" ", "_") + ".jpg" for r in respuesta.split("/")]

    for nombre_archivo in posibles_nombres:
        ruta = os.path.join(IMAGENES_DIR, nombre_archivo)
        if os.path.exists(ruta):
            return ruta

    return None  # Si ninguna imagen existe, retorna None
