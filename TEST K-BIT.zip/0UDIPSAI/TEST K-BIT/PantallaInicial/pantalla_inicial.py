import tkinter as tk
from tkinter import ttk
from datetime import datetime
import sys
import os
import json

# Añade el directorio de SubTestVocabulario al path para poder importar InterfazTestA
sys.path.append(os.path.join(os.path.dirname(__file__), "..", "SubTestVocabulario"))
from interfazTestA import InterfazTestA

# Constante que define el nombre del archivo JSON donde se guardarán los resultados
RESULTADOS_JSON = "resultados.json"

class PantallaInicial:
    def __init__(self, root):
        """
        Inicializa la pantalla inicial para recopilar los datos del examinado.
        
        :param root: La ventana principal de la aplicación.
        """
        self.root = root
        self.root.title("Datos del Examinado")  # Título de la ventana
        self.root.geometry("600x700")  # Tamaño inicial de la ventana
        self.root.state('zoomed')  # Iniciar maximizado
        self.root.configure(bg="#ddeeff")  # Color de fondo de la ventana
        
        # Variables para almacenar los datos del formulario
        self.nombre = tk.StringVar()
        self.apellidos = tk.StringVar()
        self.sexo = tk.StringVar()
        self.lugar_nacimiento = tk.StringVar()
        self.lugar_residencia = tk.StringVar()
        self.estudios = tk.StringVar()
        self.ocupacion = tk.StringVar()
        self.examinador = tk.StringVar()
        self.fecha_examen = tk.StringVar(value=datetime.today().strftime('%d/%m/%Y'))  # Fecha actual por defecto
        self.fecha_nacimiento = tk.StringVar()
        
        # Diseño de la interfaz
        self.crear_formulario()

    def crear_formulario(self):
        """
        Crea el formulario para recopilar los datos del examinado.
        """
        frame = ttk.Frame(self.root, padding=20, relief="ridge", borderwidth=2, style="TFrame")
        frame.place(relx=0.5, rely=0.5, anchor=tk.CENTER)  # Centra el frame en la ventana
        
        # Título del formulario
        ttk.Label(frame, text="Datos del Examinado", font=("Arial", 18, "bold"), foreground="#004466").grid(row=0, column=0, columnspan=2, pady=15)
        
        # Campos del formulario
        campos = [
            ("Apellidos", self.apellidos),
            ("Nombre", self.nombre),
            ("Sexo", self.sexo, ["Varón", "Mujer"]),  # Combobox para seleccionar sexo
            ("Lugar de Nacimiento", self.lugar_nacimiento),
            ("Lugar de Residencia", self.lugar_residencia),
            ("Estudios (nivel actual o más alto alcanzado)", self.estudios),
            ("Ocupación", self.ocupacion),
            ("Examinador", self.examinador),
            ("Fecha de Examen", self.fecha_examen),
            ("Fecha de Nacimiento (DD/MM/YYYY)", self.fecha_nacimiento)
        ]
        
        # Crear etiquetas y campos de entrada para cada campo del formulario
        for i, (label, var, *args) in enumerate(campos, start=1):
            ttk.Label(frame, text=label, font=("Arial", 12), background="#ddeeff").grid(row=i, column=0, sticky='e', pady=5, padx=10)
            if args:
                ttk.Combobox(frame, textvariable=var, values=args[0], state="readonly", width=25).grid(row=i, column=1, padx=10, pady=5)
            else:
                ttk.Entry(frame, textvariable=var, width=27).grid(row=i, column=1, padx=10, pady=5)
        
        # Estilo para los botones y el frame
        style = ttk.Style()
        style.configure("TButton", font=("Arial", 12, "bold"), padding=5, background="#004466", foreground="black")
        style.map("TButton", background=[("active", "#003355")], foreground=[("active", "black")])
        style.configure("TFrame", background="#ddeeff")
        
        # Botón para iniciar el test
        iniciar_btn = ttk.Button(frame, text="Iniciar Test", command=self.iniciar_test, style="TButton")
        iniciar_btn.grid(row=len(campos) + 1, column=0, columnspan=2, pady=20)

    def calcular_edad(self):
        """
        Calcula la edad cronológica del examinado basándose en la fecha de nacimiento y la fecha de examen.
        
        :return: Una tupla con la edad en formato "X años, Y meses, Z días" y la edad en años.
        """
        try:
            fecha_nac = datetime.strptime(self.fecha_nacimiento.get(), "%d/%m/%Y").date()  # Convierte la fecha de nacimiento
            fecha_examen = datetime.strptime(self.fecha_examen.get(), "%d/%m/%Y").date()  # Convierte la fecha de examen
            anios = fecha_examen.year - fecha_nac.year - ((fecha_examen.month, fecha_examen.day) < (fecha_nac.month, fecha_nac.day))  # Calcula los años
            meses = (fecha_examen.month - fecha_nac.month - (fecha_examen.day < fecha_nac.day)) % 12  # Calcula los meses
            dias = (fecha_examen - fecha_nac.replace(year=fecha_examen.year if fecha_examen.month > fecha_nac.month or (fecha_examen.month == fecha_nac.month and fecha_examen.day >= fecha_nac.day) else fecha_examen.year - 1)).days % 30  # Calcula los días
            return f"{anios} años, {meses} meses, {dias} días", anios
        except ValueError:
            return None, None  # Si hay un error en el formato de la fecha, retorna None

    def iniciar_test(self):
        """
        Inicia el test después de validar los datos del examinado.
        """
        edad_cronologica, edad_anios = self.calcular_edad()  # Calcula la edad
        if edad_cronologica is not None:
            # Guarda los datos del examinado en un diccionario
            datos_usuario = {
                "Datos del Examinado": {
                    "Apellidos": self.apellidos.get(),
                    "Nombre": self.nombre.get(),
                    "Sexo": self.sexo.get(),
                    "Lugar de Nacimiento": self.lugar_nacimiento.get(),
                    "Lugar de Residencia": self.lugar_residencia.get(),
                    "Estudios": self.estudios.get(),
                    "Ocupación": self.ocupacion.get(),
                    "Examinador": self.examinador.get(),
                    "Fecha de Examen": self.fecha_examen.get(),
                    "Fecha de Nacimiento": self.fecha_nacimiento.get(),
                    "Edad Cronológica": edad_cronologica
                }
            }
            self.guardar_datos(datos_usuario)  # Guarda los datos en el archivo JSON
            for widget in self.root.winfo_children():
                widget.destroy()  # Limpia la ventana actual
            InterfazTestA(self.root, edad_anios)  # Inicia el Test A con la edad calculada
        else:
            print("Error: Formato de fecha incorrecto.")  # Mensaje de error si el formato de la fecha es incorrecto

    def guardar_datos(self, datos):
        """
        Guarda los datos del examinado en el archivo JSON.
        
        :param datos: Diccionario con los datos del examinado.
        """
        if os.path.exists(RESULTADOS_JSON):  # Verifica si el archivo JSON ya existe
            with open(RESULTADOS_JSON, "r") as archivo:
                try:
                    datos_existentes = json.load(archivo)  # Carga los datos existentes
                except json.JSONDecodeError:
                    datos_existentes = {}  # Si hay un error, inicializa un diccionario vacío
        else:
            datos_existentes = {}  # Si el archivo no existe, inicializa un diccionario vacío

        datos_existentes.update(datos)  # Actualiza los datos existentes con los nuevos
        with open(RESULTADOS_JSON, "w") as archivo:
            json.dump(datos_existentes, archivo, indent=4)  # Guarda los datos en el archivo JSON


if __name__ == "__main__":
    root = tk.Tk()  # Crea la ventana principal
    app = PantallaInicial(root)  # Inicia la aplicación
    root.mainloop()  # Ejecuta el bucle principal de la interfaz gráfica